=== Custom Taxonomy Loop ===
Contributors: Wilco Verhaar
Tags: taxonomy, image, meta, terms, term images, tag, upload, media, url
Requires at least: 4.4
Tested up to: 4.6
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A widget that loops the terms of a specified taxonomy with images and a custom url if needed.

== Description ==

A widget that loops the terms of a specified taxonomy with images and a custom url if needed.

**Features** 
	
* Add images to terms
* Loop taxonomy terms with a widget.
* Enough options in the widget.

== Installation ==

* Download and install using the built in WordPress plugin installer.
* Activate in the "Plugins" area of your admin by clicking the "Activate" link.
* No further setup or configuration is necessary.

== Upgrade Notice ==

= 1.0 =
* no upgrade notices yet

== Screenshots ==

1. image

== Frequently Asked Questions ==

= Where can I get support? =

Hit me up on developer.wilco@gmail.com or ask on the support forum of wordpress.org

== Changelog ==

= 1.0 =
* Initial start
